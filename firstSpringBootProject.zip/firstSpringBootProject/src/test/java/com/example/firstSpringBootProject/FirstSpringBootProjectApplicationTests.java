package com.example.firstSpringBootProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
