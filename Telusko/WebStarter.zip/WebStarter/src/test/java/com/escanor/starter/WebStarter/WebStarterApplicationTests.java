package com.escanor.starter.WebStarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
